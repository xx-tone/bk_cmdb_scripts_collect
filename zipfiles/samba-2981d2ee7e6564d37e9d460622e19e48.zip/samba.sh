#!/bin/bash

#�ýű�������Samba v4.1

#Basic Server Settings ��������
#Server Description: "test"
#Workgroup Name: "caiwu"
#Server NetBIOS Name: "canway.net"
#Allow Guest Users,Username for Guest: "tom"

#Shared Directories �����ļ�
#Share Name: "Share 1"
#File Path: "/shares"
#Description: "share files"
#Volume Label: "/dev/sda"
#permissions: Read Only;Visible;Permit Guest Access

#Shared Printers ������ӡ��
#Printers to share: "All"
#Description: "All Printers"
#permissions: Visible;Permit Guest Access


# Make sure samba is installed...
yum -y install samba

# Save any existing configuration file...
cp /etc/samba/smb.conf /etc/samba/smb_original.conf

# Create the new configuration file...
cat <<EOF >/etc/samba/smb.conf
[global]
	netbios name = canway.net
	server string = test
	workgroup = caiwu
	security = user
	encrypt passwords = yes
	map to guest = bad user
	guest account = tom
	cups options = raw

[Share 1]
	path = /shares
	comment = share files
	volume = /dev/sda
	read only = yes
	guest ok = yes

[printers]
	print ok = yes
	printing = cups
	path = /var/spool/samba
	comment = All Printers
	guest ok = yes
EOF

# Make sure shared directories exist...
mkdir -p /shares

# Set permissions for shared directories...
chmod 770  /shares

# Set selinux context for shared directories
if `selinuxenabled`
then
	semanage fcontext -a -t samba_share_t '/shares(/.*)?'
	restorecon -FRvv /shares
fi

# Enable and start samba service...
systemctl enable smb
systemctl start smb