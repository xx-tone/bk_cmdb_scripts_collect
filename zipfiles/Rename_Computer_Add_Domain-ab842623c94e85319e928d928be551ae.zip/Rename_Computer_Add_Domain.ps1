﻿
 
<#     
.NOTES 
#=========================================================================== 
# Script: Rename_Computer_Add_Domain.ps1  
# Created With:ISE 3.0  
# Author: oz-xps  
# Date: 04/26/2016 00:11:14  
# Organization: ETC SOLUTIONS 
# File Name: Rename_Computer_Add_Domain.ps1 
# Comments:  Rename and Add Server into Domain
#=========================================================================== 
.DESCRIPTION 
        Rename and Add Computer into Domain 
#> 

## assign variables
$Sleep = Start-Sleep -Seconds 4
$Space = Write-Host ""

## Assigning Variables, Change, Domain Name, OU Location 
$name    = $env:computername
$Domain  = "TekPros.com"
$OU      = "OU=Domain Controllers,DC=TekPros,DC=com"

## Getting New Name
$Newname = Read-host "Provide new name for the server..."

## Getting Credentials 
$Cred    = Get-Credential

## Adding Server Into domain with new Name
$Space
$Sleep
Write-host "Adding $Newname into $Domain..." -Fore Green
Write-host "..............................." -Fore Yellow

## Proviing Choice to Exit
write-host -nonewline "To Continue Press (Y), and Enter or script will exit" -fore Green
$response = read-host
if ( $response -ne "Y" ) { exit }

Add-Computer -ComputerName $name -Domain $Domain -NewName $Newname -Credential $cred -Restart 

