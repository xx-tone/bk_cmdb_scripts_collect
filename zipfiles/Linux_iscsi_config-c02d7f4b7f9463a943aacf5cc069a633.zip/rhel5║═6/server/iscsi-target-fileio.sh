#!/bin/bash
#�ýű�������rhel5.4�Ժ�İ汾,�Լ�rhel6�汾ϵͳ
#Details of created targets
#�ű��������£�
#IQN��"iqn.2016-12.com.example:server1"
#LUN TYPE:"fileio"
#LUN path��"/root/iscsifile"
#LUN size: "100M"
#Use CHAP authentication��Username��"root"��Password��"passwd"
#IPs for Portals��"192.168.110.1";"192.168.110.2"
#����ǽ��rhelĬ�Ϸ���ǽ
#���ϲ���Ϊ�ýű���ʾ��������ʵ��ʹ���У��밴��ʵ����Ҫ���ã������жԽű��������޸�


yum install scsi-target-utils -y
if [ $? -ne 0 ]; then

	echo "Make sure you've registered to the RHN, and have the Server subscription"

	exit 1
fi

currentTimestamp=`date +%y-%m-%d-%H:%M:%S`
iscsi_conf="/etc/tgt/targets.conf"
iscsi_conf_backup=$iscsi_conf.backup.$currentTimestamp
if [ -f "$iscsi_conf" ]; then
    echo backup $iscsi_conf to $iscsi_conf_backup
    cp $iscsi_conf $iscsi_conf_backup
fi
echo "Start target service, and set it to run on startup"
service tgtd restart && chkconfig tgtd on
echo "Configure the target"

#Clean all the previous data
tgt-admin --delete ALL
#Define an iSCSI target name
tgtadm --lld iscsi --op new --mode target --tid=1 --targetname iqn.2016-12.com.example:server1
#To view the currect configuration
tgtadm --lld iscsi --op show --mode target



#Add a logical unit to the target
dd if=/dev/zero of=/root/iscsifile bs=1M count=100
chcon -Rv -t tgtd_var_lib_t /root/iscsifile
tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 1 -b /root/iscsifile




tgtadm --lld iscsi --op bind --mode target --tid 1 -I 192.168.110.1

tgtadm --lld iscsi --op bind --mode target --tid 1 -I 192.168.110.2


#Set CHAP authentication
tgtadm --lld iscsi --mode account --op new --user root --password passwd
tgtadm --lld iscsi --mode account --op bind --tid 1 --user root

#View the current configuration again
echo "View the current iSCSI target configuration"
tgtadm --lld iscsi --op show --mode target


echo "Save the target configuration"
tgt-admin --dump > /etc/tgt/targets.conf

lsmod | grep ip_tables
if [ $? == 0 ]; then
    iptables -I INPUT -p tcp -m tcp --dport 3260 -j ACCEPT 
    service iptables save
    service iptables restart
fi

