#!/bin/bash
#This is a script for iSCSI target on RHEL7

#Details of created targets
#�ű��������£�
#IQN��"iqn.2016-12.com.example:server1"
#LUN TYPE:"pscsi"
#LUN name��"pscsi0_sr0"
#LUN path��"/dev/sr0"
#Initiator name��"iqn.2016-12.com.example:desktop1"(the name of iscsi client name)
#Use CHAP authentication��Username��"root"��Password��"passwd"
#IPs for Portals��"192.168.110.1";"192.168.110.2"
#����ǽ��rhelĬ�Ϸ���ǽ
#���ϲ���Ϊ�ýű���ʾ��������ʵ��ʹ���У��밴��ʵ����Ҫ���ã������жԽű��������޸�


yum -y install targetcli
if [ $? -ne 0 ]; then
 echo "Make sure you've registered to the RHN, and have the Server subscription"
 exit 1
fi

currentTimestamp=`date +%y-%m-%d-%H:%M:%S`
iscsi_conf="/etc/target/saveconfig.json"
iscsi_conf_backup=$iscsi_conf.backup.$currentTimestamp
if [ -f "$iscsi_conf" ]; then
    echo backup $iscsi_conf to $iscsi_conf_backup
    cp $iscsi_conf $iscsi_conf_backup
fi
echo "Start target service, and set it to run on startup"
systemctl start target && systemctl enable target
echo "Configure the target"

targetcli /backstores/pscsi create name=pscsi0_sr0 dev=/dev/sr0
		
targetcli /iscsi create iqn.2016-12.com.example:server1

targetcli /iscsi/iqn.2016-12.com.example:server1/tpg1/acls create iqn.2016-12.com.example:desktop1

targetcli /iscsi/iqn.2016-12.com.example:server1/tpg1/acls/iqn.2016-12.com.example:desktop1 set auth userid=root
targetcli /iscsi/iqn.2016-12.com.example:server1/tpg1/acls/iqn.2016-12.com.example:desktop1 set auth password=passwd

targetcli /iscsi/iqn.2016-12.com.example:server1/tpg1/luns create /backstores/pscsi/pscsi0_sr0 

targetcli /iscsi/iqn.2016-12.com.example:server1/tpg1/portals delete 0.0.0.0 3260
targetcli /iscsi/iqn.2016-12.com.example:server1/tpg1/portals create 192.168.110.1 3260
targetcli /iscsi/iqn.2016-12.com.example:server1/tpg1/portals create 192.168.110.2 3260


echo "Save the target configuration"
targetcli saveconfig



systemctl status firewalld
if [ $? == 0 ]; then 
    firewall-cmd --permanent --add-port=3260/tcp
    firewall-cmd --reload
fi
