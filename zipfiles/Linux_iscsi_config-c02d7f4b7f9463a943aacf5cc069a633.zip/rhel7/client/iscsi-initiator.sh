#!/bin/bash
#This is a script for iSCSI initiator on RHEL7

#Details of created targets
#�ű��������£�
#Initiator name:iqn."2016-12.com.example:desktop1"(the name of iscsi client name)
#Target name��"iqn.2016-12.com.example:server1"
#Server port:"3260"
#Server IP/Host:"192.168.110.1"
#Use CHAP authentication��Username��"root"��Password��"passwd"
#���ϲ���Ϊ�ýű���ʾ��������ʵ��ʹ���У��밴��ʵ����Ҫ���ã������жԽű��������޸�


currentTimestamp=`date +%y-%m-%d-%H:%M:%S`

yum install -y iscsi-initiator-utils
if [ $? -ne 0 ]; then
 echo "Make sure you've registered to the RHN, and have the Server subscription"
 exit 1
fi

configFile1=/etc/iscsi/initiatorname.iscsi
configFile1Backup=$configFile1.backup.${currentTimestamp}
configFile2=/etc/iscsi/iscsid.conf
configFile2Backup=$configFile2.backup.${currentTimestamp}
if [ -f $configFile1 ]; then
	echo backup $configFile1 $configFile1Backup
	cp $configFile1 $configFile1Backup
fi
if [ -f $configFile2 ]; then
	echo backup $configFile2 $configFile2Backup
	cp $configFile2 $configFile2Backup
fi

cat <<EOF > /etc/iscsi/initiatorname.iscsi
InitiatorName=iqn.2016-12.com.example:desktop1
EOF
echo "Start iscsi service, and set it to run on startup"
systemctl start iscsi && systemctl enable iscsi
echo "Configure the initiator"


iscsiadm -m discovery -t st -p 192.168.110.1:3260

iscsiadm -m node --targetname iqn.2016-12.com.example:server1 -p 192.168.110.1:3260 -o update -n node.session.auth.username -v root
iscsiadm -m node --targetname iqn.2016-12.com.example:server1 -p 192.168.110.1:3260 -o update -n node.session.auth.password -v passwd

iscsiadm -m node -T iqn.2016-12.com.example:server1 -p 192.168.110.1:3260 -l


echo "Print the avaliable blocks on your system"
lsblk
