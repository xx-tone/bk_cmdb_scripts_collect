##########################################################
# Get-DHCPServerBackup.ps1
#---------------------------------------------------------
# Author: Kevin M. Sparenberg
# Revision History:
#     1.0 - 2010-12-10: Initial Release
##########################################################

# Create a file location for temporary storage of the DHCP Servers
$DHCPFile = $env:temp + "\DHCP_Servers.txt"
# Write the contents to the file
netsh dhcp show server > $DHCPFile

# Text File Format:
#----------------------------------------------------------------------------
# XX Servers were found in the directory service:
#
#        Server [dhcpserver1.fully.qualified.domain] Address [XXX.XXX.XXX.XXX] Ds location: cn=dhcpserver1.fully.qualified.domain
#
#        Server [dhcpserver2.fully.qualified.domain] Address [XXX.XXX.XXX.XXX] Ds location: cn=dhcpserver2.fully.qualified.domain
#
#         [ --------------------------------------------- TRUNCATED FOR SPACE --------------------------------------------- ]
#
#        Server [dhcpserverN-1.fully.qualified.domain] Address [XXX.XXX.XXX.XXX] Ds location: cn=dhcpserverN-1.fully.qualified.domain
#
#        Server [dhcpserverN.fully.qualified.domain] Address [XXX.XXX.XXX.XXX] Ds location: cn=dhcpserverN.fully.qualified.domain
#
#/

# Get the content from text file
$DHCPFileContent = Get-Content -Path $DHCPFile

# Delete the file (no need for it after Get-Content command
Remove-Item $DHCPFile

# Creative way to skip the last two and first four lines - save to same variable
$DHCPFileContent = $DHCPFileContent | `
Select-Object -Last ( $DHCPFileContent.Count - 2 ) | `
Select-Object -First ( $DHCPFileContent.Count - 4 )

# Create new collection for processing the file
$DHCPClean = @()
# Split the string (array of characters) at each tab marker.
# If the line length is zero (empty line) skip it
ForEach ($Line in $DHCPFileContent)
{
    if ( $Line.Trim.Length -ne 0 )
    {
        $DHCPClean += $Line.Split("`t ")
    }
}

# Create new Collection for further processing
$DHCP = @()
# Break apart the line based on the hard open bracket ("[") character
For ( $i = 0 ; $i -le ( $DHCPClean.Length - 1 ) ; $i++ )
{
    if ( $DHCPClean[$i].StartsWith("[") ) 
    {
        $DHCP += $DHCPClean[$i]
    }
}

# Build new collection for the "real" data.
$colDHCPServers = @()
For ( $i = 0 ; $i -le ( $DHCP.Length - 1 ) ; $i++ )
{
    # Create PowerShell Object for the Information
	$DHCPServer = New-Object PSObject
    # Add Server's Fully Qualified Domain Name as the first element in the object
	$DHCPServer | Add-Member -MemberType NoteProperty -Name ServerFQDN -Value ($DHCP[$i].Replace("[", "")).Replace("]", "")
    # Add Server's IP Address as the second element in the object
	$DHCPServer | Add-Member -MemberType NoteProperty -Name IPAddress -Value ($DHCP[++$i].Replace("[", "")).Replace("]", "")
    # Add the object to the collection
	$colDHCPServers += $DHCPServer
}

# Variable Cleanup
#--------------------------------------------------------------------------------
Remove-Variable DHCPFileContent   # Contains file content
Remove-Variable DHCPClean         # Contains formatted file content
Remove-Variable DHCP              # Contains still further formatted file content

# Begin the real backup process

ForEach ( $DHCPServer in $colDHCPServers )
{
	# Create string with the output location for the backup files
	$OutputPath = "C:\DHCP-Backup\" + $DHCPServer.ServerFQDN.Split(".")[0].ToUpper() + "-" + (Get-Date -Format "yyyyMMdd") + ".txt"
	# Notify User of current process
	Write-Host Creating $OutputPath
	# Use "netsh" command to dump the DHCP information to the local computer
	netsh dhcp server $DHCPServer.IPAddress dump > $OutputPath
}